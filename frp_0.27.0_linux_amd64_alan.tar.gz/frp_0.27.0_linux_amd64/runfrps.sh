/home/lifefresh07/frp_0.27.0_linux_amd64/frps -c /home/lifefresh07/frp_0.27.0_linux_amd64/frps.ini
